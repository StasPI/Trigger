﻿using System.Text.Json.Nodes;

namespace Helps
{
    public static class ConvertObject
    {
        //ToDo delete com code
        //public static async Task<List<string>> ListJsonObjectToListString(List<JsonObject> jo)
        //{
        //    return await Task.FromResult(jo.AsParallel().AsOrdered().Select(x => x.ToJsonString()).ToList());
        //}
        //public static async Task<List<JsonObject>> ListStringToJsonObject(List<string> st)
        //{
        //    return await Task.FromResult(st.AsParallel().AsOrdered().Select(x => JsonNode.Parse(x).AsObject()).ToList());
        //}
        public static async Task<string> JsonObjectToStringAsync(JsonObject jo)
        {
            return await Task.FromResult(jo.ToJsonString());
        }
        public static async Task<JsonObject> StringToJsonObjectAsync(string st)
        {
            return await Task.FromResult(JsonNode.Parse(st).AsObject());
        }
    }
}