﻿using Dto.Registration;

namespace Messages
{
    public class EventMessage
    {
        public List<UseCasesSendEventDto> EventMessages { get; set; }
    }
}
