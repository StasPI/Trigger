﻿using Dto.Registration;

namespace Messages
{
    public class ReactionMessage
    {
        public List<UseCasesSendReactionDto> ReactionMessages { get; set; }
    }
}