﻿namespace WebApi.Worker.Options
{
    public class WorkerReactionsOptions
    {
        public int DelayMs { get; set; }
        public int MaxMessages { get; set; }
    }
}
