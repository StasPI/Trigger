﻿namespace WebApi.Worker.Options
{
    public class ProducerReactionOptions
    {
        public string ExchangeName { get; set; }
        public string RoutingKeyName { get; set; }
    }
}
