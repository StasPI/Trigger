﻿namespace WebApi.Worker.Options
{
    public class ProducerEventOptions
    {
        public string ExchangeName { get; set; }
        public string RoutingKeyName { get; set; }
    }
}
