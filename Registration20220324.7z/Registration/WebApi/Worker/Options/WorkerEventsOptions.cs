﻿namespace WebApi.Worker.Options
{
    public class WorkerEventsOptions
    {
        public int DelayMs { get; set; }
        public int MaxMessages { get; set; }
    }
}
