﻿namespace Worker.Implementation
{
    public class WorkerOptions
    {
        public int MaxNumberOfMessages { get; set; }
        public int DelayMs { get; set; }
    }
}
