﻿namespace Worker.Implementation
{
    public class SendMessages
    {
    }
}
