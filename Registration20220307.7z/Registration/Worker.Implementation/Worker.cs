﻿namespace Worker.Implementation
{
    public class Worker
    {

    }
}